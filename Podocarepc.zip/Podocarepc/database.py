import sqlite3
from datetime import datetime

DB_NAME = "podocare.db"


# -------------------------------
# Database Connection
# -------------------------------
def get_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn


# -------------------------------
# Create Database/Table
# -------------------------------
def init_db():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS readings(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        device_id TEXT,

        timestamp TEXT,

        temperature REAL,

        pressure REAL,

        spo2 REAL,

        heart_rate REAL,

        risk_score REAL,

        ai_decision TEXT

    )
    """)

    conn.commit()
    conn.close()


# -------------------------------
# Insert Reading
# -------------------------------
def insert_reading(data):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""

    INSERT INTO readings(

        device_id,
        timestamp,
        temperature,
        pressure,
        spo2,
        heart_rate,
        risk_score,
        ai_decision

    )

    VALUES(?,?,?,?,?,?,?,?)

    """, (

        data.get("device_id", "PodoCare-001"),

        data.get(
            "timestamp",
            datetime.now().isoformat(timespec="seconds")
        ),

        float(data.get("temperature", 0)),

        float(data.get("pressure", 0)),

        float(data.get("spo2", 0)),

        float(data.get("heart_rate", 0)),

        float(data.get("risk_score", 0)),

        data.get("ai_decision", "UNKNOWN")

    ))

    conn.commit()
    conn.close()


# -------------------------------
# Latest Reading
# -------------------------------
def get_latest_reading():

    conn = get_connection()

    row = conn.execute("""

    SELECT *

    FROM readings

    ORDER BY id DESC

    LIMIT 1

    """).fetchone()

    conn.close()

    if row is None:
        return None

    return dict(row)


# -------------------------------
# Reading History
# -------------------------------
def get_all_readings(limit=100):

    conn = get_connection()

    rows = conn.execute("""

    SELECT *

    FROM readings

    ORDER BY id DESC

    LIMIT ?

    """, (limit,)).fetchall()

    conn.close()

    return [dict(r) for r in rows]


# -------------------------------
# Statistics
# -------------------------------
def get_statistics():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT COUNT(*) FROM readings"
    )
    total = cursor.fetchone()[0]

    cursor.execute("""

        SELECT COUNT(*)

        FROM readings

        WHERE ai_decision='ANOMALY'

    """)
    anomalies = cursor.fetchone()[0]

    cursor.execute("""

        SELECT AVG(risk_score)

        FROM readings

    """)
    avg_risk = cursor.fetchone()[0]

    cursor.execute("""

        SELECT MAX(risk_score)

        FROM readings

    """)
    max_risk = cursor.fetchone()[0]

    conn.close()

    avg_risk = round(avg_risk or 0, 2)
    max_risk = round(max_risk or 0, 2)

    anomaly_pct = 0

    if total > 0:
        anomaly_pct = round(
            anomalies * 100 / total,
            2
        )

    return {

        "total": total,

        "anomalies": anomalies,

        "avg_risk": avg_risk,

        "max_risk": max_risk,

        "anomaly_pct": anomaly_pct

    }
from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

from database import (
    init_db,
    insert_reading,
    get_latest_reading,
    get_all_readings
)

app = Flask(__name__)
CORS(app)

# Initialize database
init_db()


# ==========================================================
# POST sensor data from Android
# ==========================================================
@app.route("/data", methods=["POST"])
def receive_data():

    try:
        data = request.get_json()

        if not data:
            return jsonify({
                "status": "error",
                "message": "No JSON received"
            }), 400

        insert_reading(data)

        return jsonify({
            "status": "success",
            "message": "Reading stored successfully"
        }), 200

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


# ==========================================================
# Latest Reading
# ==========================================================
@app.route("/latest", methods=["GET"])
def latest():

    try:

        reading = get_latest_reading()

        if reading is None:
            return jsonify({}), 200

        return jsonify(reading), 200

    except Exception as e:

        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


# ==========================================================
# Reading History
# ==========================================================
@app.route("/history", methods=["GET"])
def history():

    try:

        limit = request.args.get("limit", default=50, type=int)

        readings = get_all_readings(limit)

        return jsonify(readings), 200

    except Exception as e:

        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


# ==========================================================
# Dashboard Statistics
# ==========================================================
@app.route("/cumulative", methods=["GET"])
def cumulative():

    try:

        conn = sqlite3.connect("podocare.db")
        conn.row_factory = sqlite3.Row

        cursor = conn.cursor()

        cursor.execute("""

            SELECT

                COUNT(*) AS total,

                AVG(risk_score) AS avg_risk,

                MAX(risk_score) AS max_risk,

                SUM(
                    CASE
                        WHEN ai_decision='ANOMALY'
                        THEN 1
                        ELSE 0
                    END
                ) AS anomalies

            FROM readings

        """)

        row = cursor.fetchone()

        conn.close()

        total = row["total"] or 0
        anomalies = row["anomalies"] or 0

        anomaly_pct = 0

        if total > 0:
            anomaly_pct = round(
                anomalies * 100.0 / total,
                1
            )

        return jsonify({

            "total": total,

            "avg_risk": round(
                row["avg_risk"] or 0,
                1
            ),

            "max_risk": round(
                row["max_risk"] or 0,
                1
            ),

            "anomalies": anomalies,

            "anomaly_pct": anomaly_pct

        }), 200

    except Exception as e:

        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


# ==========================================================
# Health Check
# ==========================================================
@app.route("/", methods=["GET"])
def home():

    return jsonify({

        "project": "PodoCare AI",

        "status": "Running",

        "apis": [
            "/data",
            "/latest",
            "/history",
            "/cumulative"
        ]

    })


# ==========================================================
# Run Server
# ==========================================================
if __name__ == "__main__":

    print("======================================")
    print("      PodoCare AI Flask Server")
    print("======================================")
    print("Server Address:")
    print("http://0.0.0.0:5000")
    print("======================================")

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )
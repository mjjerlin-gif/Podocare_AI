import sqlite3
import requests
from datetime import datetime

DB_PATH = "podocare.db"

def get_latest():
    try:
        r = requests.get(
            "http://127.0.0.1:5000/latest",
            timeout=2
        )
        return r.json()
    except:
        return {}

def get_history(limit=50):
    try:
        r = requests.get(
            f"http://127.0.0.1:5000/history?limit={limit}",
            timeout=2
        )
        return r.json()
    except:
        return []

def get_cumulative():
    try:
        r = requests.get(
            "http://127.0.0.1:5000/cumulative",
            timeout=2
        )
        return r.json()
    except:
        return {
            "avg_risk":    0,
            "max_risk":    0,
            "total":       0,
            "anomalies":   0,
            "anomaly_pct": 0
        }

def get_clinical_advice(
    risk_score, ai_decision,
    temp, pres, spo2
):
    if ai_decision == "ANOMALY" or risk_score > 75:
        return {
            "level": "CRITICAL",
            "title": "⚠️ Immediate Medical Attention",
            "advice": [
                "Visit hospital or emergency immediately",
                "Do not walk — elevate the foot",
                "Check for visible wounds or redness",
                "Contact your diabetes care team now",
                "Avoid tight footwear until reviewed"
            ]
        }
    elif risk_score > 50:
        return {
            "level": "WARNING",
            "title": "⚠️ Elevated Risk — Monitor Closely",
            "advice": [
                "Seek doctor consultation within 24 hours",
                "Check wound dressing if present",
                "Apply prescribed antiseptic",
                "Reduce walking — rest the foot",
                "Monitor temperature every 2 hours"
            ]
        }
    elif risk_score > 30:
        return {
            "level": "CAUTION",
            "title": "🟡 Early Warning — Stay Alert",
            "advice": [
                "Increase monitoring frequency",
                "Inspect foot visually twice daily",
                "Ensure proper footwear and dry socks",
                "Follow prescribed medication schedule",
                "Maintain blood sugar levels"
            ]
        }
    else:
        return {
            "level": "NORMAL",
            "title": "✅ Foot Health is Stable",
            "advice": [
                "Continue daily foot inspection routine",
                "Keep foot dry and clean",
                "Wear properly fitted diabetic footwear",
                "Exercise as recommended by doctor",
                "Next scheduled check-up on time"
            ]
        }
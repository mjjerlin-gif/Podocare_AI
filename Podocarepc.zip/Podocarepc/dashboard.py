import streamlit as st
import pandas as pd
import time
from datetime import datetime
from backend import (
    get_latest,
    get_history,
    get_cumulative,
    get_clinical_advice
)

st.set_page_config(
    page_title="PodoCare AI Dashboard",
    page_icon="🦶",
    layout="wide"
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
    background-color: #0A0F1E !important;
    color: #F9FAFB;
}
.navbar {
    background: linear-gradient(90deg,#0A0F1E,#111827);
    padding: 16px 28px;
    border-radius: 0 0 16px 16px;
    border-bottom: 1px solid #1F2937;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 24px;
}
.navbar-title { color:#00C6FF; font-size:24px; font-weight:700; }
.navbar-sub   { color:#6B7280; font-size:12px; }
.metric-card {
    background:#111827;
    border-radius:14px;
    padding:20px;
    border:1px solid #1F2937;
    text-align:center;
    margin-bottom:16px;
}
.metric-value { font-size:32px; font-weight:700; margin:6px 0; }
.metric-label {
    font-size:10px; font-weight:700;
    letter-spacing:1.5px; color:#6B7280;
    text-transform:uppercase;
}
.metric-hint  { font-size:10px; color:#4B5563; }
.risk-card    { border-radius:16px; padding:24px; text-align:center; margin-bottom:16px; }
.risk-normal  { background:#0D2B1A; border:1px solid #10B981; }
.risk-caution { background:#1A1500; border:1px solid #F59E0B; }
.risk-warning { background:#1A0E00; border:1px solid #F97316; }
.risk-critical{ background:#2B0D0D; border:1px solid #EF4444; }
.advice-card  { background:#111827; border-radius:14px; padding:20px; border:1px solid #1F2937; margin-bottom:16px; }
.stat-box     { background:#111827; border-radius:12px; padding:16px; border:1px solid #1F2937; text-align:center; }
</style>
""", unsafe_allow_html=True)

# ── NAVBAR ──
st.markdown("""
<div class='navbar'>
    <div class='navbar-title'>🦶 PodoCare AI</div>
    <div class='navbar-sub'>
        Snapdragon Edge AI · No Cloud · Fully Offline
    </div>
</div>
""", unsafe_allow_html=True)

# ── SIDEBAR ──
with st.sidebar:
    st.markdown(
        "### 🦶 PodoCare AI\n"
        "**Diabetic Foot Monitor**"
    )
    st.markdown("---")
    patient_name = st.text_input("👤 Patient Name", "Patient")
    patient_age  = st.number_input(
        "Age", min_value=1, max_value=120, value=55
    )
    st.markdown("---")
    auto_refresh = st.checkbox("🔄 Auto Refresh (5s)", value=True)
    st.markdown("---")
    st.markdown(
        "**AI Model:** Isolation Forest ONNX  \n"
        "**Runtime:** Snapdragon NPU  \n"
        "**Accuracy:** 99.7%  \n"
        "**Dataset:** 5000 readings  \n"
        "**Cloud:** ❌ Not used"
    )

# ── FETCH DATA ──
latest     = get_latest()
cumulative = get_cumulative()
history    = get_history(50)

temp   = latest.get("temperature", 0)
pres   = latest.get("pressure",    0)
spo2   = latest.get("spo2",        0)
hr     = latest.get("heart_rate",  0)
ai_dec = latest.get("ai_decision", "NORMAL")
risk   = latest.get("risk_score",  0)
ts     = latest.get(
    "timestamp",
    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
)

# ── SENSOR CARDS ──
st.markdown("### 📊 Live Sensor Readings")
c1, c2, c3, c4 = st.columns(4)

with c1:
    st.markdown(f"""
    <div class='metric-card'>
        <div class='metric-label'>🌡 Temperature</div>
        <div class='metric-value' style='color:#F59E0B'>
            {temp}°C
        </div>
        <div class='metric-hint'>Normal &lt; 35°C (IWGDF)</div>
    </div>""", unsafe_allow_html=True)

with c2:
    st.markdown(f"""
    <div class='metric-card'>
        <div class='metric-label'>👟 Pressure</div>
        <div class='metric-value' style='color:#3B82F6'>
            {pres} kPa
        </div>
        <div class='metric-hint'>Normal &lt; 270 kPa</div>
    </div>""", unsafe_allow_html=True)

with c3:
    st.markdown(f"""
    <div class='metric-card'>
        <div class='metric-label'>🩸 SpO2</div>
        <div class='metric-value' style='color:#10B981'>
            {spo2}%
        </div>
        <div class='metric-hint'>Normal &gt; 95% (Fontaine)</div>
    </div>""", unsafe_allow_html=True)

with c4:
    st.markdown(f"""
    <div class='metric-card'>
        <div class='metric-label'>❤️ Heart Rate</div>
        <div class='metric-value' style='color:#EF4444'>
            {hr} bpm
        </div>
        <div class='metric-hint'>Normal 60–85 bpm</div>
    </div>""", unsafe_allow_html=True)

st.caption(f"Last updated: {ts}")

# ── RISK + ADVICE ──
left, right = st.columns([1, 1])

with left:
    st.markdown("### 🧠 AI Risk Assessment")

    if risk <= 30:
        rc = "risk-normal";  color = "#10B981"
        em = "✅"; label = "NORMAL"
    elif risk <= 50:
        rc = "risk-caution"; color = "#F59E0B"
        em = "🟡"; label = "CAUTION"
    elif risk <= 75:
        rc = "risk-warning"; color = "#F97316"
        em = "⚠️"; label = "WARNING"
    else:
        rc = "risk-critical"; color = "#EF4444"
        em = "🚨"; label = "CRITICAL"

    st.markdown(f"""
    <div class='risk-card {rc}'>
        <div style='font-size:11px;font-weight:700;
                    color:{color};letter-spacing:2px;'>
            AI DECISION
        </div>
        <div style='font-size:56px;font-weight:700;
                    color:{color};'>
            {risk:.0f}
        </div>
        <div style='font-size:11px;color:#6B7280;'>
            / 100 Risk Score
        </div>
        <div style='font-size:20px;font-weight:700;
                    color:{color};margin-top:8px;'>
            {em} {label}
        </div>
        <div style='font-size:10px;color:#6B7280;
                    margin-top:4px;'>
            Isolation Forest ONNX · Snapdragon NPU
        </div>
    </div>""", unsafe_allow_html=True)

    st.markdown("""
    <div class='advice-card'>
        <div style='font-size:11px;font-weight:700;
                    color:#6B7280;letter-spacing:1px;
                    margin-bottom:10px;'>
            RISK GUIDE
        </div>
        <div style='color:#10B981;margin-bottom:4px;'>
            🟢 0–30 &nbsp; Normal
        </div>
        <div style='color:#F59E0B;margin-bottom:4px;'>
            🟡 31–50 &nbsp; Caution
        </div>
        <div style='color:#F97316;margin-bottom:4px;'>
            🟠 51–75 &nbsp; Warning
        </div>
        <div style='color:#EF4444;'>
            🔴 76–100 &nbsp; Critical
        </div>
    </div>""", unsafe_allow_html=True)

with right:
    st.markdown("### 🩺 Clinical Advice")

    advice = get_clinical_advice(
        risk, ai_dec, temp, pres, spo2
    )

    colors = {
        "NORMAL":   ("#10B981", "#0D2B1A"),
        "CAUTION":  ("#F59E0B", "#1A1500"),
        "WARNING":  ("#F97316", "#1A0E00"),
        "CRITICAL": ("#EF4444", "#2B0D0D"),
    }
    ac, abg = colors.get(
        advice["level"], ("#10B981", "#0D2B1A")
    )

    tips_html = "".join([
        f"<div style='color:#D1D5DB;font-size:12px;"
        f"margin-bottom:8px;padding-left:8px;"
        f"border-left:3px solid {ac};'>{t}</div>"
        for t in advice["advice"]
    ])

    st.markdown(f"""
    <div style='background:{abg};border:1px solid {ac};
                border-radius:14px;padding:20px;
                margin-bottom:16px;'>
        <div style='color:{ac};font-weight:700;
                    font-size:15px;margin-bottom:14px;'>
            {advice["title"]}
        </div>
        {tips_html}
    </div>""", unsafe_allow_html=True)

    # Stats
    st.markdown("### 📈 Session Statistics")
    s1, s2 = st.columns(2)
    with s1:
        st.markdown(f"""
        <div class='stat-box'>
            <div style='font-size:24px;font-weight:700;
                        color:#00C6FF;'>
                {cumulative.get('total', 0)}
            </div>
            <div style='font-size:10px;color:#6B7280;'>
                Total Readings
            </div>
        </div>""", unsafe_allow_html=True)
    with s2:
        st.markdown(f"""
        <div class='stat-box'>
            <div style='font-size:24px;font-weight:700;
                        color:#EF4444;'>
                {cumulative.get('anomalies', 0)}
            </div>
            <div style='font-size:10px;color:#6B7280;'>
                Anomalies
            </div>
        </div>""", unsafe_allow_html=True)

    s3, s4 = st.columns(2)
    with s3:
        st.markdown(f"""
        <div class='stat-box' style='margin-top:10px;'>
            <div style='font-size:24px;font-weight:700;
                        color:#F59E0B;'>
                {cumulative.get('avg_risk', 0)}
            </div>
            <div style='font-size:10px;color:#6B7280;'>
                Avg Risk
            </div>
        </div>""", unsafe_allow_html=True)
    with s4:
        st.markdown(f"""
        <div class='stat-box' style='margin-top:10px;'>
            <div style='font-size:24px;font-weight:700;
                        color:#F97316;'>
                {cumulative.get('anomaly_pct', 0)}%
            </div>
            <div style='font-size:10px;color:#6B7280;'>
                Anomaly Rate
            </div>
        </div>""", unsafe_allow_html=True)

# ── CHARTS ──
st.markdown("### 📉 Historical Trend")

if history:
    df = pd.DataFrame(history)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp')

    t1, t2, t3, t4 = st.tabs([
        "🌡 Temperature",
        "👟 Pressure",
        "🩸 SpO2",
        "⚠️ Risk Score"
    ])

    with t1:
        st.line_chart(
            df.set_index('timestamp')['temperature'],
            color="#F59E0B"
        )
    with t2:
        st.line_chart(
            df.set_index('timestamp')['pressure'],
            color="#3B82F6"
        )
    with t3:
        st.line_chart(
            df.set_index('timestamp')['spo2'],
            color="#10B981"
        )
    with t4:
        st.line_chart(
            df.set_index('timestamp')['risk_score'],
            color="#EF4444"
        )

    st.markdown("### 📋 Reading History")
    disp = df[[
        'timestamp','temperature','pressure',
        'spo2','heart_rate','ai_decision','risk_score'
    ]].copy()
    disp.columns = [
        'Time','Temp(°C)','Pressure(kPa)',
        'SpO2(%)','HR(bpm)','AI Decision','Risk'
    ]
    st.dataframe(
        disp.tail(20),
        use_container_width=True,
        hide_index=True
    )
else:
    st.info(
        "No data yet. "
        "Start the Flask server and send from phone."
    )

# ── AUTO REFRESH ──
if auto_refresh:
    time.sleep(5)
    st.rerun()